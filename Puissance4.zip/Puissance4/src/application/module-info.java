module Puissance4 {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.base;
    requires javafx.graphics;
    requires javafx.media;
    requires javafx.swing;
    requires javafx.web;
    
    
	
	opens application to javafx.graphics, javafx.fxml;
}
